package com.lazydeveloper.tournamentgo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import es.dmoral.toasty.Toasty;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lazydeveloper.tournamentgo.MainActivity;
import com.lazydeveloper.tournamentgo.R;
import com.lazydeveloper.tournamentgo.forget_pass;
import com.yarolegovich.lovelydialog.LovelyTextInputDialog;

public class login_activity extends AppCompatActivity {
    int flag=0;
    private EditText Email,password;
    private Button Login ,Signup;
    private ProgressBar pgbar;
    private FirebaseAuth auth;
    private TextView reset;
    Users bcg;
    String email,pass;
    RelativeLayout cl;
    LinearLayout rl;
    String usr_name;
    DatabaseReference updateData;


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        //No internet connection
        cl=findViewById(R.id.NonetScreen_login);
        rl=findViewById(R.id.connected_login);
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener(){
            @Override
            public void onConnectivityChanged(int connectionType, boolean isConnected, boolean isFast){
                if(isConnected)
                {
                    cl.setVisibility(View.GONE);
                    rl.setVisibility(View.VISIBLE);
                }
                else
                {
                    cl.setVisibility(View.VISIBLE);
                    rl.setVisibility(View.GONE);
                }
            }
        });

        updateData=FirebaseDatabase.getInstance().getReference().child("Users");
        auth = FirebaseAuth.getInstance();
        Login = findViewById(R.id.login_button_login);
        Signup = findViewById(R.id.login_button_register);
        Email = findViewById(R.id.login_email);
        password = findViewById(R.id.login_pass);
        pgbar = findViewById(R.id.progressBar);
        reset = findViewById(R.id.forget_password);
        bcg = new Users();

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login_activity.this, forget_pass.class));
            }
        });
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = Email.getText().toString().trim();
                String pass = password.getText().toString().trim();

                if (email.isEmpty()) {
                    Toasty.warning(login_activity.this, "Please enter email and try again", Toast.LENGTH_SHORT).show();

                }
                if (pass.isEmpty()) {
                    Toasty.warning(login_activity.this, "Please enter password and try again", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(login_activity.this, new OnCompleteListener<AuthResult>() {
                        @SuppressLint("CheckResult")
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                startActivity(new Intent(login_activity.this, MainActivity.class));
                                FirebaseUser usr = auth.getCurrentUser();
                                pgbar.setVisibility(View.INVISIBLE);
                                Toasty.success(login_activity.this,"Sign in successful",Toast.LENGTH_SHORT).show();
                                login_activity.this.finish();

                            } else {
                                pgbar.setVisibility(View.GONE);
                                Animation shake = AnimationUtils.loadAnimation(login_activity.this, R.anim.vibrate);
                                password.startAnimation(shake);
                                Email.startAnimation(shake);
                                Toasty.error(login_activity.this, "Email id or password incorrect", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
            }
        }
    });

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email=Email.getText().toString().trim();
                pass=password.getText().toString().trim();

                if(email.isEmpty())
                {
                    Toasty.warning(login_activity.this,"Please enter email and try again",Toast.LENGTH_SHORT).show();

                }
                else if(pass.isEmpty())
                {
                    Toasty.warning(login_activity.this,"Please enter password and try again",Toast.LENGTH_SHORT).show();

                }
                else if(pass.length()<6 )
                {
                    Toasty.warning(login_activity.this,"Password Length too short",Toast.LENGTH_SHORT).show();

                }
                else
                {
                new LovelyTextInputDialog(login_activity.this, R.style.TintTheme)

                        .setTopTitle("AWESOME!")
                        .setTopTitleColor(getResources().getColor(R.color.dialog_2_text))
                        .setTopColor(getResources().getColor(R.color.dialog_2))
                        .setTitle("PUBG username.")
                        .setMessage("Good now please enter your PUBG username so we can finalize your account.")
                        .setConfirmButtonColor(getResources().getColor(R.color.dialog_2))
                        .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                        .setConfirmButton("Submit", new LovelyTextInputDialog.OnTextInputConfirmListener() {
                            @Override
                            public void onTextInputConfirmed(String text) {


                                user_name_checker(text);

                                Handler handler=new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {


                               if(flag==1)
                               {
                                   Toasty.error(login_activity.this,"Username already in use!").show();

                               }
                                else
                                {
                                    pgbar.setVisibility(View.VISIBLE);
                                    auth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(login_activity.this, new OnCompleteListener<AuthResult>() {
                                        @Override
                                        public void onComplete(@NonNull Task<AuthResult> task) {

                                            if(task.isSuccessful())
                                            {
                                                startActivity(new Intent(login_activity.this,MainActivity.class));

                                                Users bcgk=new Users("0","",usr_name);
                                                FirebaseDatabase.getInstance().getReference("Users").child(auth.getUid()).setValue(bcgk);
                                                pgbar.setVisibility(View.INVISIBLE);
                                               login_activity.this.finish();
                                                Toasty.success(login_activity.this,"Sign up successful",Toast.LENGTH_SHORT).show();
                                            }
                                            else
                                            {
                                                pgbar.setVisibility(View.GONE);
                                                Toasty.error(login_activity.this,"Some error occured.Please try again",Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    });
                                }
                                    }
                                },1500);

                            }
                        })
                        .show();
                }

        }}
        );

    }
    public void user_name_checker(String text)
    {
        flag=0;
        usr_name=text;

        updateData.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    if (usr_name.equals(snapshot.child("user_name").getValue().toString())) {
                        flag = 1;
                        break;
                    }

                }

            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
            }


        });


    }


}
