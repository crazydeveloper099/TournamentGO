package com.lazydeveloper.tournamentgo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.FirebaseApiNotAvailableException;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lazydeveloper.tournamentgo.R;

import java.io.IOException;

public class edit_profile extends AppCompatActivity {
        EditText fst_name,last_name,userId,email,phone;
        String uID;
        Button bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        fst_name=findViewById(R.id.first_name);
        last_name=findViewById(R.id.last_name);
        userId=findViewById(R.id.pubg_user_name);
        email=findViewById(R.id.email_settings_user);
        phone=findViewById(R.id.phone_settings);
        uID=FirebaseAuth.getInstance().getUid();
        bt=findViewById(R.id.confirm_edi_profile);
        check_fst_name();
        check_lst_name();
        set_userId();
        check_phone();
        email.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());

    bt.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            button_pressed();
        }
    });
    }

        public void check_fst_name()
        {
            final DatabaseReference DBref=FirebaseDatabase.getInstance().getReference().child("Users").child(uID);
            DBref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.child("first_name").exists())
                    {
                        fst_name.setText(dataSnapshot.child("phone").getValue().toString());
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    public void check_lst_name()
    {
        final DatabaseReference DBref=FirebaseDatabase.getInstance().getReference().child("Users").child(uID);
        DBref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("last_name").exists())
                {
                    last_name.setText(dataSnapshot.child("last_name").getValue().toString());

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void set_userId()
    {
        DatabaseReference DBref=FirebaseDatabase.getInstance().getReference().child("Users").child(uID).child("user_name");
        DBref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                {
                    userId.setText(dataSnapshot.getValue().toString());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void check_phone()
    {
        final DatabaseReference DBref=FirebaseDatabase.getInstance().getReference().child("Users").child(uID);
        DBref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("phone").exists())
                {
                    phone.setText(dataSnapshot.child("phone").getValue().toString());

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void button_pressed()
    {
        DatabaseReference mdat=FirebaseDatabase.getInstance().getReference().child("Users").child(uID);
        mdat.child("first_name").setValue(fst_name.getText().toString());
        mdat.child("last_name").setValue(last_name.getText().toString());
        mdat.child("phone").setValue(phone.getText().toString());

    }


    }


