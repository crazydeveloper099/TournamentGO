package com.lazydeveloper.tournamentgo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lazydeveloper.tournamentgo.Contact_us_activity;
import com.lazydeveloper.tournamentgo.R;
import com.lazydeveloper.tournamentgo.edit_profile;
import com.lazydeveloper.tournamentgo.login_activity;
import com.lazydeveloper.tournamentgo.model_for_settings_list_view;

import java.util.ArrayList;
import java.util.Objects;

public class settings extends AppCompatActivity {
Toolbar toolbar;
TextView title,text_userID,text_Email,text_wallet_balance,logout;

DatabaseReference dbRefrence;
ListView lv;
ArrayList<model_for_settings_list_view> arrayList;
String uID;
ImageView back_arrow;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        lv=findViewById(R.id.list_view_settings);

        back_arrow=findViewById(R.id.back_arrow);
        set_arrow_button();
        logout=findViewById(R.id.logout_button);

        uID=Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
        text_userID=findViewById(R.id.pubgId);
        text_Email=findViewById(R.id.email_user);
        text_wallet_balance=findViewById(R.id.balance_wallet_value);

        text_Email.setText(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getEmail());

        setText_wallet_balance();
        setText_userID();
        arrayList=new ArrayList<model_for_settings_list_view>();
        arrayList.add(new model_for_settings_list_view("Edit Profile","Change your name,number and description"));
        arrayList.add(new model_for_settings_list_view("Wallet","Add and view your wallet"));
        arrayList.add(new model_for_settings_list_view("Stats","View your purchased,won and participated matches."));
        arrayList.add(new model_for_settings_list_view("Contact us","Contact customer support through email and get support within 24hrs."));

        settings_list_adapter adapter=new settings_list_adapter(this,arrayList);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0)
                {
                    startActivity(new Intent(settings.this, edit_profile.class));
                }
                if(position==1)
                {
                    startActivity(new Intent(settings.this, Wallet_page.class));
                }
                if(position==2)
                {
                    startActivity(new Intent(settings.this, Statics_settings.class));
                }
                if(position==3)
                {
                    startActivity(new Intent(settings.this, Contact_us_activity.class));
                }
            }
        });
        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settings.this.finish();
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlert_logout();
            }
        });

    }
    public void setText_wallet_balance()
    {
        dbRefrence= FirebaseDatabase.getInstance().getReference().child("Users").child(uID).child("wallet_amount");
        dbRefrence.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                text_wallet_balance.setText(" ₹"+dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    public void setText_userID()
    {
        dbRefrence= FirebaseDatabase.getInstance().getReference().child("Users").child(uID).child("user_name");
        dbRefrence.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                text_userID.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    public void set_arrow_button()
    {

    }
    public void showAlert_logout()
    {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(settings.this);
        builder1.setMessage("Logout ?");
        builder1.setCancelable(true);
        builder1.setMessage("Are you sure you want to logout?");
        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                       FirebaseAuth.getInstance().signOut();
                        Intent i = new Intent(settings.this, login_activity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
