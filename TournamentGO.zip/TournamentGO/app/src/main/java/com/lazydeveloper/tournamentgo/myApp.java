package com.lazydeveloper.tournamentgo;

import android.app.Application;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.util.Log;

import com.lazydeveloper.tournamentgo.R;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import androidx.core.graphics.TypefaceCompatUtil;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

public class myApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("font/sans_medium.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
    }
}
