package com.lazydeveloper.tournamentgo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.ToastKt;
import androidx.fragment.app.FragmentManager;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import static java.util.Calendar.HOUR_OF_DAY;

public class Wallet_page extends AppCompatActivity{

    RelativeLayout cl;
    LinearLayout rl;

    TextView tv1,tv2,title;
    EditText et1;
    Button add,add_50,add_100,add_200;
    Toolbar tb;
    private DatabaseReference getMdata_ref;
    String userID=Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
    Users bcg;
    ImageView arrow;


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet_page);

        //No internet connection
        cl=findViewById(R.id.NonetScreen_wallet);
        rl=findViewById(R.id.connected_wallet);
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener(){
            @Override
            public void onConnectivityChanged(int connectionType, boolean isConnected, boolean isFast){
                if(isConnected)
                {
                    cl.setVisibility(View.GONE);
                    rl.setVisibility(View.VISIBLE);
                }
                else
                {
                    cl.setVisibility(View.VISIBLE);
                    rl.setVisibility(View.GONE);
                }
            }
        });
        title=findViewById(R.id.title_add_money);
        Typeface custom_font2 = Typeface.createFromAsset(getAssets(), "font/sans_bold.ttf");
        title.setTypeface(custom_font2);
        arrow=findViewById(R.id.back_arrow_wallet);
        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Wallet_page.this.finish();
            }
        });
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "font/sans_medium.ttf");
        tb=findViewById(R.id.toolbar_wallet);


        getMdata_ref=FirebaseDatabase.getInstance().getReferenceFromUrl("https://tournament-go.firebaseio.com/Users");
        tv2=findViewById(R.id.textView_rs_symbol);
        tv2.setTypeface(custom_font);

        tv1=findViewById(R.id.textView3);
        tv1.setTypeface(custom_font);
        getMdata_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                bcg=new Users();
                bcg.setWallet_amount(dataSnapshot.child(userID).getValue(Users.class).getWallet_amount());
                tv1.setText(bcg.getWallet_amount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        et1=findViewById(R.id.et_wallet);
        et1.setTypeface(custom_font);
        add=findViewById(R.id.add_money_button_wallet);
        add.setTypeface(custom_font);

        add_50=findViewById(R.id.add_50_button_wallet);
        add_50.setTypeface(custom_font);

        add_100=findViewById(R.id.add_100_button_wallet);
        add_100.setTypeface(custom_font);

        add_200=findViewById(R.id.add_200_button_wallet);
        add_200.setTypeface(custom_font);
        TextView info=findViewById(R.id.textView_info);
        info.setTypeface(custom_font);

        add.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Date time= Calendar.getInstance().getTime();

                SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                String formattedDate = df.format(time);
                SimpleDateFormat tf = new SimpleDateFormat("HH:mm");
                String formattedTime = tf.format(time);
                String credit="CREDIT-"+formattedDate+"-"+formattedTime+"-"+et1.getText().toString();
                FirebaseDatabase.getInstance().getReference().child("Users").child(userID).child("transactions").push().setValue(credit);


            }
        });
        add_50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("50");
            }
        });
        add_100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("100");
            }
        });
        add_200.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("200");
            }
        });

    }



}
