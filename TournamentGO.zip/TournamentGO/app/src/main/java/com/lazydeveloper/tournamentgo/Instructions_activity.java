package com.lazydeveloper.tournamentgo;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.Movie;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;
import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.lazydeveloper.tournamentgo.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import static android.view.View.MeasureSpec.makeMeasureSpec;
import static com.facebook.FacebookSdk.getApplicationContext;
import static com.paytm.pgsdk.easypay.manager.PaytmAssist.getContext;

public class Instructions_activity extends AppCompatActivity {
    TextView tv,date_view,rule1,rule2,rule3,rule4,rule5,rule6,rule7,rule8,rules_heading,match_info,room_id_name,room_pass_name,room_id_value
            ,room_pass_value,map_name,map_value,type_name,type_value,contestant;
    Typeface zag;
    DatabaseReference mdata_ref ;
    RelativeLayout cl;
    LinearLayout rl;
    RecyclerView RView;

    ImageView image,iv;;
    ArrayList<list_view_constant> arrayList=new ArrayList<>();
    contestant_adapter adapter;
    DatabaseReference getimage;
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_instructions_activity);

        cl=findViewById(R.id.NonetScreen_Instructions);
        rl=findViewById(R.id.connected_Instructions);
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener(){
            @Override
            public void onConnectivityChanged(int connectionType, boolean isConnected, boolean isFast){
                if(isConnected)
                {
                    cl.setVisibility(View.GONE);
                    rl.setVisibility(View.VISIBLE);
                }
                else
                {
                    cl.setVisibility(View.VISIBLE);
                    rl.setVisibility(View.GONE);
                }
            }
        });
        Typeface custom_font2 = Typeface.createFromAsset(getAssets(), "font/sans_bold.ttf");
        zag=Typeface.createFromAsset(getAssets(),"font/zag.ttf");
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "font/sans_medium.ttf");
        map_value=findViewById(R.id.map_value);
        type_value=findViewById(R.id.type_value);
        room_id_value=findViewById(R.id.room_id_value);
        room_pass_value=findViewById(R.id.room_password_value);
        contestant=findViewById(R.id.contestants_heading);
        contestant.setTypeface(zag);
        map_value.setTypeface(custom_font);
        type_value.setTypeface(custom_font);
        room_id_value.setTypeface(custom_font);
        room_pass_value.setTypeface(custom_font);
        iv=findViewById(R.id.back_button_instructions_2);
        image=findViewById(R.id.image_instructions_activity);
        Bundle bundle=getIntent().getExtras();
        String a=bundle.getString("time");
        String b=bundle.getString("date");
        String pressed=bundle.getString("key");
        getImage(pressed);
        mdata_ref = FirebaseDatabase.getInstance().getReference().child("Cardjava").child(pressed);
        get_map_type();
        tv=findViewById(R.id.time_view);

        date_view=findViewById(R.id.date_view);
        rule1=findViewById(R.id.rule_1);
        rule2=findViewById(R.id.rule_2);
        rule3=findViewById(R.id.rule_3);
        rule4=findViewById(R.id.rule_4);
        rule5=findViewById(R.id.rule_5);
        rule6=findViewById(R.id.rule_6);
        rule7=findViewById(R.id.rule_7);
        rule8=findViewById(R.id.rule_8);
        match_info=findViewById(R.id.match_info);
        room_id_name=findViewById(R.id.room_id_text);
        room_pass_name=findViewById(R.id.room_password_text);
        rules_heading=findViewById(R.id.rules_heading);

        map_name=findViewById(R.id.MAP_text);
        type_name=findViewById(R.id.type_name);

        rule1.setTypeface(custom_font);
        rule2.setTypeface(custom_font);
        rule3.setTypeface(custom_font);
        rule4.setTypeface(custom_font);
        rule5.setTypeface(custom_font);
        rule6.setTypeface(custom_font);
        rule7.setTypeface(custom_font);
        rule8.setTypeface(custom_font);

        date_view.setTypeface(custom_font);
        match_info.setTypeface(zag);
        room_id_name.setTypeface(custom_font);
        room_pass_name.setTypeface(custom_font);
        rules_heading.setTypeface(zag);
        map_name.setTypeface(custom_font);
        type_name.setTypeface(custom_font);

        update_list(pressed);
        date_view.setText(b);
        tv.setText(a);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Instructions_activity.this.finish();
            }
        });

    }


    //to get map data
    public void get_map_type()
    {
        mdata_ref.child("map").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                map_value.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mdata_ref.child("team").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                type_value.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mdata_ref.child("r_id").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                room_id_value.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mdata_ref.child("r_pass").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                room_pass_value.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    public void getImage(String key)
    {

        getimage=FirebaseDatabase.getInstance().getReference().child("Cardjava").child(key).child("image");
        getimage.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() == null) {
                    image.setVisibility(View.GONE);
                } else {
                    final Callback loadedCallback = new Callback() {
                        @Override
                        public void onSuccess() {
                            /** shimmerText.stopShimmer();
                             linearLayout112.setVisibility(View.INVISIBLE);
                             recyclerView112.setVisibility(View.VISIBLE);**/
                        }

                        @Override
                        public void onError() {
                        }
                    };
                    image.setTag(loadedCallback);


                    Picasso.with(Instructions_activity.this).load(dataSnapshot.getValue().toString()).into(image, loadedCallback);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    //to get list of contestants
    public void update_list(String key)
    {
        RView=findViewById(R.id.recycler_view_constant);
        adapter=new contestant_adapter(arrayList,this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        RView.setLayoutManager(mLayoutManager);
        RView.setItemAnimator(new DefaultItemAnimator());
        RView.setAdapter(adapter);


        FirebaseDatabase.getInstance().getReference().child("Cardjava").child(key).child("users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds:dataSnapshot.getChildren())
                {
                    String s=ds.getValue(String.class);
                    list_view_constant list=new list_view_constant(s,0);
                    arrayList.add(list);
                    adapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
class contestant_adapter extends RecyclerView.Adapter<contestant_adapter.MyViewHolder>
{
    Context ctx;



    private ArrayList<list_view_constant> contestantList;
    public contestant_adapter(ArrayList<list_view_constant> contestantList, Context ctx) {
        this.contestantList = contestantList;
        this.ctx=ctx;

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView name1;
        public TextView index;

        public MyViewHolder(View view) {

            super(view);
            name1 = view.findViewById(R.id.text_view_constant_name);
            Typeface custom_font2 = Typeface.createFromAsset(ctx.getAssets(),"font/sans_bold.ttf");

            index=view.findViewById(R.id.number_contestant);
            name1.setTypeface(custom_font2);
            name1.setTextColor(Color.parseColor("#000000"));
            index.setTypeface(custom_font2);
            index.setTextColor(Color.parseColor("#000000"));


        }
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contestant_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        list_view_constant cont = contestantList.get(position);

        holder.name1.setText(cont.getName());
        holder.index.setText("•");



    }



    @Override
    public int getItemCount() {
        return contestantList.size();
    }

}

