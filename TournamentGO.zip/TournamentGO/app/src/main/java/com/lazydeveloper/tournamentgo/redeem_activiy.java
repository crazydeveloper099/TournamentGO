package com.lazydeveloper.tournamentgo;

import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import cn.pedant.SweetAlert.SweetAlertDialog;
import es.dmoral.toasty.Toasty;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.lazydeveloper.tournamentgo.R;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

public class redeem_activiy extends AppCompatActivity {


    TextView rs_symb, wllt_amt, heading, tandc, rs_symbol_2;
    EditText phone_paytm, amount_redeem;
    Button button_redeem;
    Toolbar tb;
    ImageView imageView;
    RelativeLayout cl;
    LinearLayout rl;

    String userID = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
    DatabaseReference getMdata_ref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://tournament-go.firebaseio.com/Users");
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redeem_activiy);

        //No internet connection

        cl=findViewById(R.id.NonetScreen_redeem);
        rl=findViewById(R.id.connected_redeem);
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener(){
            @Override
            public void onConnectivityChanged(int connectionType, boolean isConnected, boolean isFast){
                if(isConnected)
                {
                    cl.setVisibility(View.GONE);
                    rl.setVisibility(View.VISIBLE);
                }
                else
                {
                    cl.setVisibility(View.VISIBLE);
                    rl.setVisibility(View.GONE);
                }
            }
        });

        tb=findViewById(R.id.toolbar_redeem);

       imageView=findViewById(R.id.back_button_redeem);
        rs_symb = findViewById(R.id.textView_rs_symbol);
        wllt_amt = findViewById(R.id.textView3);
        heading = findViewById(R.id.heading);
        phone_paytm = findViewById(R.id.phone_paytm);
        amount_redeem = findViewById(R.id.amount_paytm);
        rs_symbol_2 = findViewById(R.id.textView_rs_symbol_2);
        button_redeem = findViewById(R.id.redeem_bt);
        tandc = findViewById(R.id.TandC);
        Typeface custom_font2 = Typeface.createFromAsset(getAssets(), "font/sans_bold.ttf");
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "font/sans_medium.ttf");
        rs_symb.setTypeface(custom_font);
        wllt_amt.setTypeface(custom_font);
        heading.setTypeface(custom_font2);
        phone_paytm.setTypeface(custom_font);
        amount_redeem.setTypeface(custom_font);
        rs_symbol_2.setTypeface(custom_font);
        button_redeem.setTypeface(custom_font);
        tandc.setTypeface(custom_font);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                redeem_activiy.this.finish();
            }
        });
        set_wallet_amount();
        button_redeem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                post_redeem_request();

            }
        });

    }

    public void set_wallet_amount() {
        getMdata_ref.child(userID).child("wallet_amount").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                wllt_amt.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void post_redeem_request() {
        if (is_numeric(amount_redeem.getText().toString()) && is_valid_pohone(phone_paytm.getText().toString())) {
            if ((Integer.parseInt(wllt_amt.getText().toString()) - Integer.parseInt(amount_redeem.getText().toString()))>= 0) {
                //to update wallet amount
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://tournament-go.firebaseio.com/");
                databaseReference.child("Redeem_Request").child(userID).child("wallet_amount").setValue(wllt_amt.getText().toString());
                databaseReference.child("Redeem_Request").child(userID).child("phone").setValue(phone_paytm.getText().toString());
                databaseReference.child("Redeem_Request").child(userID).child("redeem_amount").setValue(amount_redeem.getText().toString());

                getMdata_ref.child(userID).child("wallet_amount").setValue(String.valueOf(Integer.parseInt(wllt_amt.getText().toString()) - Integer.parseInt(amount_redeem.getText().toString())));
                post_transcationUpdate();


            } else {
                Toast.makeText(this, "Insufficient balance!!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Incorrect phone number or amount", Toast.LENGTH_SHORT).show();
        }
    }
    public Boolean is_numeric(String str)
    {

        try{
            return Integer.parseInt(str) > 0 && Integer.parseInt(str) < 10000;
        }catch (NumberFormatException ex) {
           return false;
        }
    }
    public Boolean is_valid_pohone(String str)
    {
        if(str.length()>=10 && str.length()<=13)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void post_transcationUpdate()
    {
        Date time= Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = df.format(time);
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm");
        String formattedTime = tf.format(time);
        String debit="DEBIT-"+formattedDate+"-"+formattedTime+"-"+amount_redeem.getText().toString();
        FirebaseDatabase.getInstance().getReference().child("Users").child(userID).child("transactions").push().setValue(debit);
        new SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                .setTitleText("Done!")

                .setContentText("Your amount will be transferred to your Paytm wallet within 24hrs.Thanks.")
                .show();
        phone_paytm.setText("");
        amount_redeem.setText("");

    }
}
