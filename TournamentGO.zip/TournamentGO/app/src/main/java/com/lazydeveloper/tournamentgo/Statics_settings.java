package com.lazydeveloper.tournamentgo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.lazydeveloper.tournamentgo.R;

public class Statics_settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statics_settings);
    }
}
