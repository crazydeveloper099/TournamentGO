package com.lazydeveloper.tournamentgo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.lazydeveloper.tournamentgo.MainActivity;
import com.lazydeveloper.tournamentgo.R;
import com.lazydeveloper.tournamentgo.login_activity;

public class splash_screen extends AppCompatActivity {

    private int time=700;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);
        TextView tv1=findViewById(R.id.tv1);
        TextView tv2=findViewById(R.id.tv2);

        Typeface custom_font2 = Typeface.createFromAsset(getAssets(),"font/Strenuous.ttf");
        tv1.setTypeface(custom_font2);
        tv2.setTypeface(custom_font2);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(user==null)
                {
                    Intent intent=new Intent(splash_screen.this, login_activity.class);
                    startActivity(intent);
                    splash_screen.this.finish();
                }
                else
                {
                    Intent intent=new Intent(splash_screen.this, MainActivity.class);
                    startActivity(intent);
                    splash_screen.this.finish();
                }
            }
        },time);









    }
}
