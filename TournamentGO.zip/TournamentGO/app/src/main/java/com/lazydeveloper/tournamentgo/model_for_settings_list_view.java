package com.lazydeveloper.tournamentgo;

public class model_for_settings_list_view {
    String heading;
    String description;

    public model_for_settings_list_view(String heading, String description) {
        this.heading = heading;
        this.description = description;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
