package com.lazydeveloper.tournamentgo;

/**
 * Created by anubhav on 09-12-2018.
 */

public class Users
{
    private String wallet_amount;
    private String match_number;
    private String user_name;


    public Users() {

    }

    public Users(String wallet_amount,String match_number,String user_name) {
        this.wallet_amount = wallet_amount;
        this.match_number = match_number;
        this.user_name=user_name;
    }

    public String getWallet_amount() {
        return wallet_amount;
    }

    public void setWallet_amount(String wallet_amount) {
        this.wallet_amount = wallet_amount;
    }

    public String getMatch_number() {
        return match_number;
    }

    public void setMatch_number(String match_number) {
        this.match_number = match_number;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }


}
