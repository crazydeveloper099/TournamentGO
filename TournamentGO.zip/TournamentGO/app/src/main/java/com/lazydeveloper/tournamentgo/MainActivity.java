package com.lazydeveloper.tournamentgo;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;

import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;

import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.facebook.shimmer.ShimmerFrameLayout;

import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.github.javiersantos.materialstyleddialogs.enums.Duration;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.AlertDialog;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.DividerDrawerItem;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.SecondaryDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IProfile;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.yarolegovich.lovelydialog.LovelyTextInputDialog;

import org.jetbrains.annotations.NotNull;
import org.w3c.dom.Text;

import java.util.Objects;

import es.dmoral.toasty.Toasty;
import io.supercharge.shimmerlayout.ShimmerLayout;
import me.toptas.fancyshowcase.FancyShowCaseQueue;
import me.toptas.fancyshowcase.FancyShowCaseView;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private Toolbar mtoolbar;

    SkeletonScreen skeletonScreen;
    Drawer result;
    AccountHeader headerResult;
    private RecyclerView rv;
    private DatabaseReference mdata_ref;
    FirebaseRecyclerAdapter<Cardjava, card_view_holder> adapter;
    int a,b;

    Button tv2;
    Typeface custom_font,custom_font2;
    Users bcg;
    private DatabaseReference wallwt_ref;
    String userID;
    //ShimmerFrameLayout shimmerText;
    LinearLayout linearLayout112;

    DatabaseReference updateData;
    DatabaseReference db_spots;
    String n1;
    ProgressBar progressBar;

    RelativeLayout cl;
    RelativeLayout rl;
    String pressed_key;
    int spots=0;
    int executor = 0;

    TextView title;


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cl=findViewById(R.id.NonetScreen);
        rl=findViewById(R.id.connected_main);
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener(){
            @Override
            public void onConnectivityChanged(int connectionType, boolean isConnected, boolean isFast){
               if(isConnected)
               {
                   cl.setVisibility(View.GONE);
                   rl.setVisibility(View.VISIBLE);
               }
               else
               {
                   cl.setVisibility(View.VISIBLE);
                   rl.setVisibility(View.GONE);
               }
            }
        });



    rv = findViewById(R.id.list_card_views);
        skeletonScreen= Skeleton.bind(rv).adapter(adapter).load(R.layout.holder_layout).show();



        wallwt_ref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://tournament-go.firebaseio.com/Users");
        userID = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();

        mdata_ref = FirebaseDatabase.getInstance().getReference().child("Cardjava");
        db_spots=FirebaseDatabase.getInstance().getReference().child("Cardjava");

     //
        updateData = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);





        //To tell app that we are using toolbar instead odf action bar
        mtoolbar = (Toolbar) findViewById(R.id.mylol);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        custom_font = Typeface.createFromAsset(getAssets(), "font/sans_medium.ttf");
        custom_font2 = Typeface.createFromAsset(getAssets(), "font/Pacifico.ttf");


        tv2 = mtoolbar.findViewById(R.id.textView23);

        wallwt_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                bcg = new Users();
                bcg.setWallet_amount(dataSnapshot.child(userID).getValue(Users.class).getWallet_amount());
                tv2.setText("₹"+bcg.getWallet_amount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toasty.error(MainActivity.this, databaseError.getCode(), Toast.LENGTH_SHORT).show();
            }
        });
        //Navigation drawer


        IProfile profile = new ProfileDrawerItem().withName("Wallet :₹"+tv2.getText().toString()).withEmail("-").withIcon(getResources().getDrawable(R.drawable.account_header_image_2)).withIdentifier(0);
        headerResult = new AccountHeaderBuilder()
                .withActivity(MainActivity.this)
                .withPaddingBelowHeader(true)

                .addProfiles(profile)

                .withOnAccountHeaderListener(new AccountHeader.OnAccountHeaderListener() {
                    @Override
                    public boolean onProfileChanged(View view, IProfile profile, boolean currentProfile) {
                        return false;
                    }
                })
                .build();


        //to get wallet amount

        //drawer building
        new DrawerBuilder().withActivity(MainActivity.this).withAccountHeader(headerResult).build();
        PrimaryDrawerItem item1 = new PrimaryDrawerItem().withIdentifier(1).withIcon(R.drawable.wallet_nav_2).withName("My Wallet").withSelectedColor(getResources().getColor(R.color.selector_nav));
        PrimaryDrawerItem item2 = new PrimaryDrawerItem().withIdentifier(2).withIcon(R.drawable.withdraw_icon_navigation).withName("Withdraw").withSelectedColor(getResources().getColor(R.color.selector_nav));
        PrimaryDrawerItem item3 = new PrimaryDrawerItem().withIdentifier(3).withIcon(R.drawable.transactions_icon_nav).withName("My Transactions").withSelectedColor(getResources().getColor(R.color.selector_nav));
        PrimaryDrawerItem item4= new PrimaryDrawerItem().withIdentifier(4).withIcon(R.drawable.rules_icon_nav).withName("Rules").withSelectedColor(getResources().getColor(R.color.selector_nav));

        SecondaryDrawerItem item5 = new SecondaryDrawerItem().withIdentifier(5).withIcon(R.drawable.settings_nav_4).withName("Account Settings").withTextColor(getResources().getColor(R.color.text_nav)).withSelectedColor(getResources().getColor(R.color.selector_nav));
        SecondaryDrawerItem item6 = new SecondaryDrawerItem().withIdentifier(6).withIcon(R.drawable.contact_icon_nav_2).withName("Contact us").withSelectedColor(getResources().getColor(R.color.selector_nav)).withTextColor(getResources().getColor(R.color.text_nav));
        SecondaryDrawerItem item7 = new SecondaryDrawerItem().withIdentifier(7).withIcon(R.drawable.puzzle).withName("About us").withSelectedColor(getResources().getColor(R.color.selector_nav)).withTextColor(getResources().getColor(R.color.text_nav));

        result = new DrawerBuilder()
                .withActivity(MainActivity.this)
                .withToolbar(mtoolbar)
                .withAccountHeader(headerResult)
                .withSelectedItemByPosition(100)

                .addDrawerItems(
                        item1,
                        item2,
                        item3,
                        item4,
                        item5,
                        item6,
                        item7)
                .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                    @Override
                    public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {

                        if(position==1)
                        {

                            startActivity(new Intent(MainActivity.this, Wallet_page.class));
                            result.closeDrawer();return true;
                        }
                        if(position==2)
                        {

                            startActivity(new Intent(MainActivity.this, redeem_activiy.class));
                            result.closeDrawer();return true;
                        }
                        if(position==3)
                        {

                            startActivity(new Intent(MainActivity.this, transcations.class));
                            result.closeDrawer();return true;
                        }
                        if(position==4)
                        {

                            startActivity(new Intent(MainActivity.this, rules_activity.class));
                            result.closeDrawer();
                            return true;
                        }
                        if(position==5)
                        {
                            startActivity(new Intent(MainActivity.this, settings.class));
                            result.closeDrawer();
                            return true;
                        }
                        if(position==6)
                        {

                            startActivity(new Intent(MainActivity.this, Contact_us_activity.class));
                            result.closeDrawer(); return true;
                        }
                        else
                        {

                            return false;
                        }

                    }

                })
                .build();
        result.addStickyFooterItem(new PrimaryDrawerItem().withIcon(R.drawable.logout_icon).withName("Logout").withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
            @Override
            public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                showAlert_logout();
                return true;
            }
        }));
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);

        DatabaseReference dbr=FirebaseDatabase.getInstance().getReference().child("Users").child(userID).child("wallet_amount");
        dbr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                IProfile profile = new ProfileDrawerItem().withName("Wallet :₹"+dataSnapshot.getValue()).withEmail(FirebaseAuth.getInstance().getCurrentUser().getEmail()).withIcon(getResources().getDrawable(R.drawable.account_header_image_2)).withIdentifier(0);
                headerResult.removeProfile(0);
                headerResult.addProfile(profile,0);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        //drawer ends here





        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Wallet_page.class);
                startActivity(intent);
            }
        });

        Query personsQuery = mdata_ref.orderByKey();

        FirebaseRecyclerOptions personsOptions = new FirebaseRecyclerOptions.Builder<Cardjava>().setQuery(personsQuery, Cardjava.class).build();
        //Recycler view starts
        rv = findViewById(R.id.list_card_views);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));


        adapter = new FirebaseRecyclerAdapter<Cardjava, card_view_holder>(personsOptions) {
            @Override
            protected void onBindViewHolder(@NonNull final card_view_holder holder, int position, @NonNull Cardjava model) {

                holder.set_img(getBaseContext(), model.getImage());
                holder.setDescription(model.getDescription());
                holder.set1stamount("₹"+model.getFst_amt());
                holder.set2ndamount("₹" + model.getScnd_amt());
                holder.set3rdamount("₹"+model.getThird_amt());
                holder.set_date_value(model.getDate_value());
                holder.set_time_value(model.getTime_value());
                holder.setkill_per("₹"+model.getPer_kill_value());
                holder.set_spots(model.getSpots());
                holder.setFst("1ST");
                holder.setScnd("2ND");
                holder.setThird("3RD");
                holder.setDevice(model.getDevice());
                holder.setTeam(model.getTeam());
                holder.setDate("DATE");
                holder.setTime("TIME");
                holder.setPer_kill("PRICE");

                Button m=holder.mview.findViewById(R.id.button99);
                final Typeface custom_font2 = Typeface.createFromAsset(getAssets(), "font/Strenuous.ttf");

                m.setTypeface(custom_font2);
                if(model.getScnd_amt()==null)
                {
                    TextView textVie=holder.mview.findViewById(R.id.scnd);
                    textVie.setVisibility(View.GONE);
                    TextView textVie2=holder.mview.findViewById(R.id.scnd_amt);
                    textVie2.setVisibility(View.GONE);
                    holder.setThird("PER KILL");

                }


                holder.mview.findViewById(R.id.progressBar).setVisibility(View.GONE);
                final TextView tv1=holder.mview.findViewById(R.id.spots_left);
                final ProgressBar pgBar=holder.mview.findViewById(R.id.activeProgress);

               mdata_ref.child(getRef(holder.getAdapterPosition()).getKey()).child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                      tv1.setText(String.valueOf(dataSnapshot.getChildrenCount())+"/100 Joined");
                      pgBar.setProgress((int)dataSnapshot.getChildrenCount());
                      db_spots.child(getRef(holder.getAdapterPosition()).getKey()).child("spots_occupied").setValue(String.valueOf(dataSnapshot.getChildrenCount()));

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                db_spots.child(getRef(holder.getAdapterPosition()).getKey()).child("spots_occupied").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(Integer.parseInt(dataSnapshot.getValue().toString())==5)
                        {

                            Button bt=holder.mview.findViewById(R.id.button99);
                            bt.setEnabled(false);
                            bt.setText("MATCH FULL");
                            bt.setBackgroundResource(R.drawable.button_shape_full);
                            bt.setText("MATCH FULL");
                            bt.setTypeface(custom_font);
                            bt.setTextColor(Color.parseColor("#FFFFFF"));
                            bt.setTextSize(TypedValue.COMPLEX_UNIT_SP,10);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });




                holder.mview.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        bubble_wallet(holder);
                        Toasty.info(MainActivity.this,"Please wait",Toast.LENGTH_SHORT).show();
                        progressBar=holder.mview.findViewById(R.id.progressBar);
                        progressBar.setVisibility(View.VISIBLE);
                        executor=0;

                        pressed_key = getRef(holder.getAdapterPosition()).getKey();
                        availability_checker(pressed_key);
                        purchase_checker();
                        final TextView time=holder.mview.findViewById(R.id.time_value);
                        final TextView date=holder.mview.findViewById(R.id.date_value);
                        final TextView map=holder.mview.findViewById(R.id.description);
                        final Handler handler = new Handler();

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {


                                progressBar.setVisibility(View.GONE);
                                if (spots >= 100) {

                                    Toasty.error(MainActivity.this, "MATCH FULL", Toast.LENGTH_SHORT).show();
                                } else {

                                    if (executor == 0) {


                                        a = Integer.parseInt(tv2.getText().toString().trim().substring(1));
                                        b = Integer.parseInt(n1);
                                            if (a >= b) {
                                                new MaterialStyledDialog.Builder(MainActivity.this)
                                                        .setTitle("Confirm Payment?")
                                                        .withDivider(true)

                                                        .setDescription("₹" + n1 + " will be deducted from your Wallet press Yes to confirm")
                                                        .setHeaderColor(R.color.dialog_top)
                                                        .setIcon(R.drawable.round_local_atm_white_48)
                                                        .withIconAnimation(false)
                                                        .withDialogAnimation(true, Duration.FAST)
                                                        .setPositiveText("Yes")
                                                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                            @Override
                                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                                                String deduct = String.valueOf(a - b);
                                                                updateData.child("wallet_amount").setValue(deduct);
                                                                updateData.child("purchased").push().setValue(pressed_key);
                                                                Toasty.success(MainActivity.this,"Payment successful",Toast.LENGTH_SHORT).show();

                                                                                Toasty.success(MainActivity.this,"Success",Toast.LENGTH_SHORT).show();
                                                                                add_on_purchase(pressed_key);
                                                                                Intent intent=new Intent(MainActivity.this, Instructions_activity.class);
                                                                                intent.putExtra("time", time.getText().toString());
                                                                                intent.putExtra("date",date.getText().toString());
                                                                                intent.putExtra("key",pressed_key);
                                                                                startActivity(intent);

                                                            }
                                                        })
                                                        .setNegativeText("No")
                                                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                                                            @Override
                                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                                Toasty.info(MainActivity.this, "You Cancelled the transcation", Toast.LENGTH_SHORT).show();

                                                            }
                                                        })
                                                        .show();
                                            } else {
                                                Toasty.error(MainActivity.this, "Insufficient Balance!!", Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(MainActivity.this, Wallet_page.class));
                                        }
                                    } else if (executor == 1) {
                                        Intent intent=new Intent(MainActivity.this, Instructions_activity.class);
                                        intent.putExtra("time", time.getText().toString());
                                        intent.putExtra("date",date.getText().toString());
                                        intent.putExtra("key",pressed_key);
                                        startActivity(intent);

                                    }
                                }
                            }
                        }, 1500);

                    }

                });
                holder.mview.findViewById(R.id.button99).setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        bubble_wallet(holder);
                        Toasty.info(MainActivity.this,"Please wait").show();

                        progressBar=holder.mview.findViewById(R.id.progressBar);
                        progressBar.setVisibility(View.VISIBLE);
                        executor=0;

                        pressed_key = getRef(holder.getAdapterPosition()).getKey();
                        availability_checker(pressed_key);
                        Toast.makeText(MainActivity.this, String.valueOf(spots), Toast.LENGTH_SHORT).show();
                        purchase_checker();
                        final TextView time=holder.mview.findViewById(R.id.time_value);
                        final TextView date=holder.mview.findViewById(R.id.date_value);
                        final TextView map=holder.mview.findViewById(R.id.description);
                        final Handler handler = new Handler();

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {


                                progressBar.setVisibility(View.GONE);
                                if (spots >= 100) {

                                    Toasty.error(MainActivity.this, "MATCH FULL", Toast.LENGTH_SHORT).show();
                                } else {

                                    if (executor == 0) {


                                        a = Integer.parseInt(tv2.getText().toString().trim().substring(1));
                                        b = Integer.parseInt(n1);
                                        if (a >= b) {
                                            new MaterialStyledDialog.Builder(MainActivity.this)
                                                    .setTitle("Confirm Payment?")
                                                    .withDivider(true)
                                                    .setDescription("₹" + n1 + " will be deducted from your Wallet press Yes to confirm")
                                                    .setHeaderColor(R.color.dialog_top)
                                                    .setIcon(R.drawable.round_local_atm_white_48)
                                                    .withIconAnimation(true)
                                                    .withDialogAnimation(true, Duration.NORMAL)
                                                    .setPositiveText("Yes")
                                                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                                                        @Override
                                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                                            String deduct = String.valueOf(a - b);
                                                            updateData.child("wallet_amount").setValue(deduct);
                                                            updateData.child("purchased").push().setValue(pressed_key);
                                                            Toasty.success(MainActivity.this,"Purchase successful",Toasty.LENGTH_SHORT).show();

                                                                            Toasty.success(MainActivity.this,"Success",Toast.LENGTH_SHORT).show();
                                                                            add_on_purchase(pressed_key);
                                                                            Intent intent=new Intent(MainActivity.this, Instructions_activity.class);
                                                                            intent.putExtra("time", time.getText().toString());
                                                                            intent.putExtra("date",date.getText().toString());
                                                                            intent.putExtra("key",pressed_key);
                                                                            startActivity(intent);
                                                                 }
                                                    })
                                                    .setNegativeText("No")
                                                    .onNegative(new MaterialDialog.SingleButtonCallback() {
                                                        @Override
                                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                            Toasty.info(MainActivity.this, "You Cancelled the transcation", Toast.LENGTH_SHORT).show();

                                                        }
                                                    })
                                                    .show();
                                        } else {
                                            startActivity(new Intent(MainActivity.this, Wallet_page.class));
                                            Toasty.error(MainActivity.this, "Insufficient Balance!!", Toast.LENGTH_SHORT).show();
                                        }
                                    } else if (executor == 1) {
                                        Intent intent=new Intent(MainActivity.this, Instructions_activity.class);
                                        intent.putExtra("time", time.getText().toString());
                                        intent.putExtra("date",date.getText().toString());
                                        intent.putExtra("key",pressed_key);
                                        startActivity(intent);

                                    }
                                }
                            }
                        }, 1500);

                    }

                });


            }

            @NonNull
            @Override
            public card_view_holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(viewGroup.getContext())

                        .inflate(R.layout.card_viewww, viewGroup, false);

                return new MainActivity.card_view_holder(view);
            }
        };
        rv.setAdapter(adapter);
        executor = 0;

    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    protected void onResume() {
        super.onResume();

      //  shimmerText.startShimmer();
      //  shimmer_and_loading();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    //setting values of text_vies and images in card_view
    public class card_view_holder extends RecyclerView.ViewHolder {
        Typeface custom_font = Typeface.createFromAsset(getAssets(), "font/sans_medium.ttf");
        Typeface custom_font2 = Typeface.createFromAsset(getAssets(), "font/sans_bold.ttf");

        public String image1;
        View mview;

        public card_view_holder(View itemView) {
            super(itemView);
            mview = itemView;
        }

        public void setTeam(String team) {
            TextView mteam = mview.findViewById(R.id.team);
            mteam.setText(team);
        }
        public void setDevice(String device) {
            TextView mdevice = mview.findViewById(R.id.device);
            mdevice.setText(device);
        }

        public void setDescription(String description) {
            TextView mdescription = mview.findViewById(R.id.description);
            mdescription.setTypeface(custom_font2);
            mdescription.setText(description);
        }




        public void set1stamount(String fst_amt) {
            TextView set1st_amt = mview.findViewById(R.id.fst_amt);
            set1st_amt.setTypeface(custom_font);
            set1st_amt.setText(fst_amt);
        }

        public void set2ndamount(String scnd_amt) {
            TextView set2nd_amt = mview.findViewById(R.id.scnd_amt);
            set2nd_amt.setTypeface(custom_font);

            set2nd_amt.setText(scnd_amt);
        }

        public void set3rdamount(String third_amt) {
            TextView set3rd_amt = mview.findViewById(R.id.third_amt);
            set3rd_amt.setTypeface(custom_font);
            set3rd_amt.setText(third_amt);
        }



        public void set_date_value(String date_value) {
            TextView st_value = mview.findViewById(R.id.date_value);
            st_value.setTypeface(custom_font);
            st_value.setText(date_value);
        }

        public void set_time_value(String time_value) {
            TextView tm_value = mview.findViewById(R.id.time_value);
            tm_value.setTypeface(custom_font);
            tm_value.setText(time_value);
        }

        public void setkill_per(String per_kill_value) {
            TextView set_p_k_v = mview.findViewById(R.id.per_kill_value);
            set_p_k_v.setTypeface(custom_font);
            set_p_k_v.setText(per_kill_value);
        }

        public void set_img(final Context ctx, String image) {
            ImageView set_img = mview.findViewById(R.id.image_card_view);
            final Callback loadedCallback = new Callback()
            {
                @Override
                public void onSuccess()
                {






                }
                     @Override
                    public void onError() {
                    }
            };
            set_img.setTag(loadedCallback);


            Picasso.with(ctx).load(image).into(set_img,loadedCallback);

        }

        public void set_spots(String spots) {
            TextView spt = mview.findViewById(R.id.spots_left);

            spt.setText(spots);
        }

        public void setFst(String fst)
        {
            TextView prz=mview.findViewById(R.id.fst);
            prz.setTypeface(custom_font);
            prz.setText(fst);

        }
        public void setScnd(String scnd)
        {
            TextView prz=mview.findViewById(R.id.scnd);
            prz.setTypeface(custom_font);
            prz.setText(scnd);
        }
        public void setThird(String third)
        {
            TextView prz=mview.findViewById(R.id.thirdee);
            prz.setTypeface(custom_font);
            prz.setText(third);
        }
        public void setDate(String date)
        {
            TextView prz=mview.findViewById(R.id.date_name);
            prz.setTypeface(custom_font);
            prz.setText(date);
        }
        public void setTime(String time)
        {
            TextView prz=mview.findViewById(R.id.time_name);
            prz.setTypeface(custom_font);
            prz.setText(time);
        }
        public void setPer_kill(String per_kill)
        {
            TextView prz=mview.findViewById(R.id.per_kill);
            prz.setTypeface(custom_font);
            prz.setText(per_kill);
        }

    }

    @Override
    public void onBackPressed() {
        if (result.isDrawerOpen()) {
            result.closeDrawer();
        } else {
            super.onBackPressed();
        }
    }



    void purchase_checker()
    {

        updateData.child("purchased").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String val;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    val = snapshot.getValue().toString();
                    if (val.equals(pressed_key)) {
                        executor = 1;
                        break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    public void availability_checker(String key)
    {
        final DatabaseReference dbr=FirebaseDatabase.getInstance().getReference().child("Cardjava").child(key);
        mdata_ref.child(key).child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                spots= (int) dataSnapshot.getChildrenCount();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mdata_ref.child(key).child("per_kill_value").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                n1=dataSnapshot.getValue().toString();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {


            }}); }
            public void bubble_wallet(card_view_holder holder)
            {
                final FancyShowCaseView showCaseView1=new FancyShowCaseView.Builder(this)
                        .title("Winner Winner Chicken Dinner amount for first prize.")
                        .titleSize(15, TypedValue.COMPLEX_UNIT_SP)
                        .showOnce("fancy1")
                        .focusOn(holder.mview.findViewById(R.id.fst_amt))
                        .build();
                final FancyShowCaseView showCaseView2=new FancyShowCaseView.Builder(this)
                        .title("Prize for top 2nd team.")
                        .titleSize(15, TypedValue.COMPLEX_UNIT_SP)
                        .showOnce("fancy1")
                        .focusOn(holder.mview.findViewById(R.id.scnd_amt))
                        .build();
                final FancyShowCaseView showCaseView3=new FancyShowCaseView.Builder(this)
                        .title("Top 3rd team will also get a prize!")
                        .titleSize(15, TypedValue.COMPLEX_UNIT_SP)
                        .showOnce("fancy1")
                        .focusOn(holder.mview.findViewById(R.id.third_amt))
                        .build();
                final FancyShowCaseView showCaseView4=new FancyShowCaseView.Builder(this)
                        .title("Winning amount will be reflected in the wallet which can be redeemed to payTM.")
                        .titleSize(15, TypedValue.COMPLEX_UNIT_SP)
                        .showOnce("fancy1")
                        .focusOn(tv2)
                        .build();
                final FancyShowCaseView showCaseView5=new FancyShowCaseView.Builder(this)
                        .title("Team type for a match is indicated here like Squad,Duo or Solo.")
                        .titleSize(15, TypedValue.COMPLEX_UNIT_SP)
                        .showOnce("fancy1")
                        .focusOn(holder.mview.findViewById(R.id.team))
                        .build();
                final FancyShowCaseView showCaseView6=new FancyShowCaseView.Builder(this)
                        .title("Device type like Emulator,Mobile or Both will be indicated here.")
                        .titleSize(15, TypedValue.COMPLEX_UNIT_SP)
                        .showOnce("fancy1")
                        .focusOn(holder.mview.findViewById(R.id.device))
                        .build();
                FancyShowCaseQueue queue=new FancyShowCaseQueue()
                        .add(showCaseView1)
                        .add(showCaseView2)
                        .add(showCaseView3)
                        .add(showCaseView4)
                        .add(showCaseView5)
                        .add(showCaseView6);
                queue.show();

            }
    public void showAlert_logout()
    {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
        builder1.setMessage("Logout ?");
        builder1.setCancelable(true);
        builder1.setMessage("Are you sure you want to logout?");
        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        FirebaseAuth.getInstance().signOut();
                        Intent i = new Intent(MainActivity.this, login_activity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
    public void add_on_purchase(final String key)
    {
        FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getUid()).child("user_name").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mdata_ref.child(key).child("users").push().setValue(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
