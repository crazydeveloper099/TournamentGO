package com.lazydeveloper.tournamentgo;

public class transcations_model_class {
    String s;
    public transcations_model_class(){


    }
    public transcations_model_class(String s) {

        this.s=s;
    }

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }
}
